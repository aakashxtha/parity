# parity — Design & Implementation Specification

**Version:** 0.1 draft
**Status:** pre-implementation
**Audience:** an AI coding agent (or human) implementing this from scratch, plus future maintainers.

---

## 0. How to use this document

This is a complete, self-contained specification. An implementer should be able to build v0 from this file alone, without asking clarifying questions about scope or behavior.

**Rules for the implementer:**

1. **Do not add features that are not in §4 (In Scope).** §5 lists explicit non-goals. If a feature seems obviously useful but is not listed, it belongs to a later version. Scope creep is the primary failure mode for this project.
2. **Do not implement any code path that writes to or modifies a structure file.** v0 is strictly read-only. See §5.
3. **§9 (Correctness Core) is the part that matters.** If time is constrained, cut CLI polish, cut output formatting, cut extra dialects — but never cut or approximate §9. A tool that reports false differences is worse than no tool.
4. **§14 lists open questions with unverified assumptions.** Do not guess at these. Verify against the cited authoritative sources before writing the relevant code, and record what you found.
5. Every milestone in §13 has a **Definition of Done**. Do not proceed to the next milestone until the current one passes.

---

## 1. One-line description

`parity` is a fast, read-only command-line tool that answers two questions about PDB/mmCIF structure files: **"what is this file?"** and **"are these two files the same molecule?"**

---

## 2. Motivation

Computational biologists move a single structure through many tools — RCSB → a modeling/repair step → a force-field-specific system builder (tleap, psfgen, CHARMM-GUI, pdb2gmx) → simulation → analysis. Each stage rewrites atom and residue names according to its own conventions, silently.

Three failure modes result, all of them expensive and none of them currently caught by tooling:

1. **False alarm.** Two files are chemically identical but text-differ in thousands of places. `diff` is useless; the researcher manually eyeballs coordinates.
2. **Silent divergence.** A prep step mutates the molecule — substitutes selenomethionine, drops a cofactor, changes a histidine tautomer, builds a loop — and nothing announces it. It surfaces weeks later as an inexplicable result.
3. **Mixed-convention corruption.** A file is assembled from pieces written by different tools (concatenated chains, a half-finished conversion, a glycan appended from a different builder). The file loads, minimizes, equilibrates, and produces garbage.

There is no tool that reports **"chemically identical, 412 atoms renamed"** or **"chain A is CHARMM, chain B is AMBER."** That gap is the product.

---

## 3. Core design insight

Both commands reduce to a single primitive. Implement the primitive once; both verbs are thin layers over it.

> **Assign every atom a canonical identity that is independent of the force field or tool that wrote the file.**

Given that:

- **`check`** = canonicalize one file, then report what was found, what was ambiguous, and what was inconsistent.
- **`diff`** = canonicalize two files, align them, and compare canonical identities.

```
                       ┌─────────────────────┐
 file(s) ──► parse ──► │ canonical resolver  │ ──► check   (1 file)
            (gemmi)    │  + dialect tables   │ ──► diff    (2 files)
                       └─────────────────────┘
```

A "difference" that disappears under canonicalization is a **naming** difference. A difference that survives canonicalization is a **real** difference. That distinction is the entire value proposition, and §9 is where it is won or lost.

---

## 4. In scope for v0

### 4.1 Commands

| Command | Inputs | Purpose |
|---|---|---|
| `parity check FILE` | 1 structure | Identify dialect, inventory contents, flag inconsistencies |
| `parity diff FILE_A FILE_B` | 2 structures | Report chemical / topological / geometric / naming differences |

### 4.2 Molecule classes

- Standard amino acids (all 20, plus the common force-field protonation variants)
- Standard nucleic acids (DNA and RNA, standard bases)
- Water and monatomic ions
- Non-standard residues and ligands: recognized and inventoried, **not** deeply canonicalized (reported as unknown, which is a first-class output, not an error)

### 4.3 Dialects

Must ship with tables for:

- `pdbv3` — the PDB format v3.0 standard (this is the **canonical reference dialect**; all others map to and from it)
- `amber` — AMBER / tleap
- `charmm` — CHARMM / psfgen / CHARMM-GUI
- `pdbv2` — legacy PDB naming (still common in older files and some tools)

Nice to have if cheap, otherwise defer: `gromacs`, `glycam`.

### 4.4 Formats

- Input: PDB and mmCIF (both, from day one — `gemmi` gives both for free, and mmCIF is mandatory for large systems since PDB format cannot represent them)
- Output: human-readable terminal report (default) and `--json`

---

## 5. Explicit non-goals for v0

Do not implement these. Do not add flags that hint at them.

- **No writing, fixing, converting, or translating.** No `--fix`, no `--apply`, no `-o out.pdb`. The tool never modifies user data. This is a trust property, not just a scope decision.
- **No `translate` verb.** It is deferred to v0.2 (§15). It requires the tables to be *complete* rather than merely *correct*, which is a much larger job.
- **No geometry validation** — no clash detection, no cis-peptide detection, no Ramachandran, no occupancy audits, no crystallographic symmetry contacts. Those belong to a separate linter tool.
- **No energy, no minimization, no topology-file reading** (`.prmtop`, `.psf`).
- **No multi-model / trajectory handling.** If a file has multiple models, use model 1 and emit a warning.
- **No network access at runtime** (see §11.3 on the CCD).
- **No GUI, no web service, no config file.** Flags only.

**Scope rule for `check`:** it may only report facts derivable from the canonical-key resolver — naming, chemical identity, completeness, internal consistency. Anything requiring new geometric or physical analysis is out.

---

## 6. CLI surface

```
parity check FILE [options]
parity diff FILE_A FILE_B [options]
```

### 6.1 Shared options

| Flag | Default | Meaning |
|---|---|---|
| `--json` | off | Emit machine-readable JSON to stdout instead of the human report |
| `--hydrogens` | off | Include hydrogens in comparison/reporting. **Off by default** — protonation states differ constantly between tools, and comparing H by default would make the tool useless out of the box |
| `--dialect NAME` | auto | Override dialect auto-detection |
| `--model N` | 1 | Which model to use in a multi-model file |
| `--quiet` | off | Suppress the report; rely on exit code only |
| `--no-color` | auto | Disable ANSI color (auto-disabled when stdout is not a TTY) |
| `--version`, `--help` | | Standard |

### 6.2 `diff`-only options

| Flag | Default | Meaning |
|---|---|---|
| `--level LEVEL` | `all` | One of `naming`, `topology`, `chemistry`, `geometry`, `all` — see §8.2 |
| `--rmsd-threshold Å` | `0.0` | Geometric differences below this are not reported |
| `--ignore-water` | off | Exclude solvent from comparison |
| `--ignore-hetatm` | off | Exclude non-polymer entities |

### 6.3 Exit codes

Deliberately `diff`-like, so the tool composes into shell pipelines, CI, Snakemake, and Nextflow with no wrapper.

| Code | Meaning |
|---|---|
| `0` | `check`: no issues. `diff`: structures are equivalent |
| `1` | `check`: issues found. `diff`: differences found |
| `2` | Error — file unreadable, unparseable, bad arguments |

---

## 7. `check` — single-file mode

### 7.1 What it reports

1. **Detected dialect** with a confidence level and the evidence that drove the decision.
2. **Inventory** — chains, residues, atoms, ligands, ions, waters.
3. **Protonation census** — histidine tautomer counts, cysteine free vs. disulfide-bonded, non-standard acid/base states (ASH/GLH/LYN and equivalents).
4. **Chain breaks and gaps** — by residue numbering *and* by CA–CA distance. These two signals disagree more often than people expect; report both and flag disagreements.
5. **Missing atoms** — per residue, against the expected heavy-atom complement for that residue type.
6. **Alternate locations** — which residues carry them.
7. **Unknown names** — atoms or residues that match no dialect table.
8. **Mixed-dialect warning** — see §7.3. This is the highest-value output of the whole command.

### 7.2 Example output (illustrative target format)

```
$ parity check prepped.pdb

  dialect     CHARMM  (confident)
                HSD/HSE/HSP · HB1/HB2 · OT1/OT2 termini · TIP3 water

  contents    2 chains · 487 residues · 7,812 atoms
              1 ligand (LIG) · 2 Zn · 41 waters

  protonation HIS: 9 HSD, 4 HSE, 1 HSP
              CYS: 6 in 3 disulfides, 4 free
              ASP/GLU: all standard

  ! gap        chain A 87-93 missing (numbering + CA-CA distance agree)
  ! altloc     3 residues carry alternate locations
  ! unknown    LIG:C17 matches no known dialect

  x 3 issues
```

### 7.3 Mixed-dialect detection (priority feature)

Run dialect scoring **per chain, and per contiguous residue segment within a chain**, not only over the whole file. Report disagreement:

```
  ! dialect    file is not internally consistent
                 chain A          CHARMM  (HSD, HB1/HB2)
                 chain B          AMBER   (HID, HB2/HB3)
                 A:201-238        GLYCAM  (glycan naming)
```

This is what a concatenated or half-converted file looks like. It survives minimization and equilibration and fails silently much later. Nothing currently detects it. Treat this as the flagship capability of `check`.

### 7.4 Batch use

`check` must behave well over many files, because this unlocks a workflow `diff` cannot:

```bash
parity check structures/*.pdb --json | jq -r 'select(.issue_count > 0) | .file'
```

Requirements: one self-contained JSON object per input file (JSON Lines when multiple files are given), no interleaved progress output on stdout, all diagnostics to stderr.

---

## 8. `diff` — two-file mode

### 8.1 Example output (illustrative target format)

Equivalent files:

```
$ parity diff 1abc_charmm.pdb 1abc_amber.pdb

  chemistry   identical
  topology    identical
  geometry    0.000 A heavy-atom RMSD
  naming      412 atoms across 23 residues

    HSD -> HIS            14 residues
    HSE -> HIS             9 residues
    HB1/HB2 -> HB2/HB3   198 atoms  (prochiral, order preserved)
    O1P/O2P -> OP1/OP2    26 atoms

  = chemically equivalent
```

Non-equivalent files:

```
$ parity diff deposited.pdb prepped.pdb

  chemistry   2 differences
  topology    3 differences
  geometry    0.31 A heavy-atom RMSD

  ! MSE 214 -> MET 214          selenomethionine substituted
  ! GOL 401 removed             crystallization additive
  + residues 87-93              built (absent in deposited)
  ~ HIS 63                      HID -> HIE (tautomer changed)

  x structures are not equivalent
```

### 8.2 Difference levels

Every detected change is classified into exactly one level. This classification **is** the product; get the taxonomy right before writing the renderer.

| Level | Definition | Examples |
|---|---|---|
| `naming` | Same molecule, different labels. Vanishes under canonicalization. | `HSD`→`HIS`, `HB1/HB2`→`HB2/HB3`, `O1P`→`OP1`, `TIP3`→`HOH`, ring-flip label swaps |
| `topology` | Composition of the model changed. | Residues added/removed, chains added/removed, gaps opened/closed, waters or ions stripped, altlocs resolved |
| `chemistry` | Molecular identity changed. | Mutations, `MSE`→`MET`, protonation/tautomer change, disulfide formed/broken, ligand replaced |
| `geometry` | Same atoms, moved. | Per-residue and global RMSD, ring flips (when coordinates, not labels, changed) |

**Equivalence rule:** two structures are "chemically equivalent" iff there are **zero** `chemistry` and **zero** `topology` differences. `naming` and `geometry` differences do not break equivalence. This rule determines the exit code.

### 8.3 Alignment

Files may use different numbering, may be missing residues, and may have chains in different orders. Do not assume index correspondence.

1. **Chain pairing** — pair chains between files by sequence identity, greedily, highest identity first. Report unpaired chains as topology differences.
2. **Residue alignment** — per chain pair, align sequences (`gemmi` provides sequence alignment; use it rather than writing your own). Use the alignment to map residue↔residue.
3. **Atom matching** — within aligned residue pairs, match by canonical atom key (§9.1). This is a dict lookup, not a search.
4. Fast path: if both files have identical chain IDs, residue numbering, and residue names, skip alignment entirely. This is the common case and should be near-instant.

---

## 9. Correctness core — the part that matters

If any of §9 is wrong, the tool produces false positives and no one uses it twice. Budget most of the implementation effort here.

### 9.1 The canonical atom key

```python
CanonicalAtomKey = (
    chain_id:        str,    # as given
    seq_id:          int,    # residue number
    insertion_code:  str,    # '' when absent
    canonical_resname: str,  # dialect-independent, e.g. HSD/HID/HISE -> HIS
    canonical_atomname: str, # dialect-independent, e.g. HB1 -> HB3 (see 9.3)
    altloc:          str,    # '' when absent
)
```

Canonical names are always the **PDB v3** form. `pdbv3` is the hub of the mapping star; no dialect maps directly to any other dialect.

### 9.2 Symmetry-equivalent atoms (topologically indistinguishable)

These atom pairs are related by a genuine symmetry of the residue — rotation of an aromatic ring, or resonance-equivalent terminal atoms. Swapping their labels produces **the same molecule**, and such a swap must be reported as `naming`, never as `chemistry` or `geometry`.

| Residue | Swappable set | Reason |
|---|---|---|
| PHE, TYR | `CD1`↔`CD2` **and** `CE1`↔`CE2` together | 180° ring flip; must swap as a coupled set, never independently |
| ASP | `OD1`↔`OD2` | Carboxylate resonance |
| GLU | `OE1`↔`OE2` | Carboxylate resonance |
| ARG | `NH1`↔`NH2` | Guanidinium resonance |

**Canonicalization rule:** for each symmetry set, choose the labeling deterministically from geometry (for example, order the two candidate atoms by a stable geometric criterion such as distance to a fixed reference atom in the residue, breaking ties by coordinate lexicographic order). The specific criterion does not matter; **applying the identical criterion to both files** does. Record the chosen rule in code comments — it must never change between releases without a version bump, or cached results become incomparable.

Skipping §9.2 produces hundreds of false "geometry" differences on files that are actually identical. This is the single most common reason a naive structure diff is useless.

### 9.3 Prochiral atoms (topologically distinct — do NOT treat as symmetric)

This is a distinct problem from §9.2 and must not be merged with it.

Prochiral pairs — the two hydrogens of a CH2 group (`HB2`/`HB3`, `HG2`/`HG3`, glycine `HA2`/`HA3`, …), and the two methyls of valine (`CG1`/`CG2`) and leucine (`CD1`/`CD2`) — are **chemically distinguishable**. Each has a correct assignment determined by IUPAC pro-R/pro-S rules applied to the coordinates. They are *not* freely swappable.

Two consequences:

1. **Dialect mapping of CH2 hydrogens must be geometry-aware, not string-based.** CHARMM's `HB1`/`HB2` and PDB v3's `HB2`/`HB3` refer to the same two positions, but a naive lexical map can pair them the wrong way round and silently invert stereochemistry. MD will not complain. Downstream analysis (NMR observables, stereospecific restraints, chirality checks) will be quietly wrong.
2. **A mismatched prochiral assignment is a reportable finding**, not a naming difference to be silently absorbed: `VAL 10 CG1/CG2 assignment does not follow IUPAC convention`.

**Implementation approach.** For a prochiral center C with identical substituents `a`, `b` and distinct substituents `X`, `Y`: compute the sign of the scalar triple product

```
s = ( X - C ) . [ ( Y - C ) x ( a - C ) ]
```

The sign of `s` deterministically distinguishes `a` from `b` given a fixed ordering convention for `X` and `Y`. Use it to assign the pair consistently. This is cheap and robust.

**Do not hand-derive which of `HB2`/`HB3` is pro-R.** See §14, Q1 — verify against an authoritative reference and encode the answer in the tables with a citation.

### 9.4 Residue aliasing

Map force-field protonation and modification variants to the canonical parent:

| Canonical | Aliases |
|---|---|
| `HIS` | `HSD`, `HSE`, `HSP`, `HID`, `HIE`, `HIP`, `HISD`, `HISE`, `HISH` |
| `CYS` | `CYX`, `CYM`, `CYS1`, `CYS2` |
| `ASP` | `ASH`, `ASPP` |
| `GLU` | `GLH`, `GLUP` |
| `LYS` | `LYN`, `LSN` |
| `MET` | `MSE` (selenomethionine — **chemistry difference, not naming**; see below) |
| `HOH` | `WAT`, `TIP3`, `TIP3P`, `SOL`, `T3P` |

**Critical distinction.** Aliasing must not erase information the user needs:

- `HSD` → `HIS` is a **naming** difference (same tool-independent identity, different label for the *same* tautomer convention). But `HID` → `HIE` between two files is a **chemistry** difference (the tautomer itself changed). Therefore the canonical residue identity must retain the protonation state as a separate attribute alongside the canonical parent name. Do not collapse them into one string.
- `MSE` → `MET` is a real atomic substitution (Se → S) and is always a **chemistry** difference, even though the residues are related.

Model this as: `(parent_name, protonation_state, modification)` rather than a single canonical string.

### 9.5 Hydrogens

Excluded from comparison by default (`--hydrogens` to include). Rationale: prep tools disagree about protonation constantly, hydrogen presence is often an artifact of which stage the file came from, and including them by default would bury the signal. When hydrogens *are* included, all of §9.3 applies.

---

## 10. Dialect tables

Tables are **data, not code**. Adding a force field must be a pull request against a data file, with zero Python changes. This is the main extensibility mechanism and a large part of why the project will attract contributors.

### 10.1 Format

TOML, one file per dialect, shipped in `src/parity/data/dialects/`.

### 10.2 Schema

```toml
[meta]
name = "charmm"
description = "CHARMM36 / psfgen / CHARMM-GUI naming"
reference = "URL or citation for the convention"

# ---- Residue name mapping: dialect name -> canonical identity ----
[residues.HSD]
canonical   = "HIS"
protonation = "delta"          # free-form but must be consistent across dialects

[residues.HSE]
canonical   = "HIS"
protonation = "epsilon"

[residues.HSP]
canonical   = "HIS"
protonation = "both"           # protonated / doubly protonated

[residues.TIP3]
canonical = "HOH"

# ---- Atom name mapping ----
# Global mappings apply to every residue.
[atoms.global]
"O1P" = "OP1"
"O2P" = "OP2"
"OT1" = "O"
"OT2" = "OXT"

# Per-residue mappings override global.
[atoms.ILE]
"CD" = "CD1"

# Prochiral pairs must be declared, never mapped as plain strings.
# The resolver assigns these from geometry (see spec section 9.3).
[[prochiral]]
residues  = ["*"]              # all residues having this center
center    = "CB"
dialect   = ["HB1", "HB2"]     # names in THIS dialect
canonical = ["HB2", "HB3"]     # corresponding PDB v3 names
reference = ["CA", "N"]        # the distinct substituents X, Y

# ---- Detection markers: evidence used by dialect scoring ----
[[markers]]
kind   = "residue_name"
value  = "HSD"
weight = 10

[[markers]]
kind   = "residue_name"
value  = "TIP3"
weight = 8

[[markers]]
kind   = "atom_name"
value  = "OT1"
weight = 6

[[markers]]
kind    = "atom_in_residue"
residue = "ILE"
value   = "CD"
weight  = 8
```

A separate `symmetry.toml` holds the §9.2 symmetry sets (they are dialect-independent).

### 10.3 Seed the tables from the CCD, do not hand-write them

The wwPDB **Chemical Component Dictionary** is the authoritative source for standard atom names, alternate atom names, bonding, and ideal coordinates for every component the PDB knows about. Hand-typing atom name tables guarantees typos and omissions.

Write a one-off developer script (`tools/build_tables.py`, not part of the shipped runtime) that reads the CCD and emits the baseline `pdbv3` table and the standard heavy-atom complements used for missing-atom detection in §7.1. Hand-curate only the genuinely force-field-specific deltas on top of that.

Ship the generated tables in the package. **Do not fetch the CCD at runtime** — no network access in the tool itself (§5).

---

## 11. Implementation

### 11.1 Language and dependencies

- **Python ≥ 3.10**
- **`gemmi`** — parsing (PDB *and* mmCIF), sequence alignment, chemical component handling. Do not write a PDB parser. Do not write an aligner.
- **`typer`** or **`click`** — CLI. Subcommand architecture from the first commit even though there are only two verbs; retrofitting it is annoying.
- **`rich`** *(optional)* — terminal formatting. Acceptable, but must degrade to plain text when not a TTY.
- **`tomllib`** — stdlib on 3.11+; `tomli` backport for 3.10.
- **`numpy`** — geometry. **Lazy-import it** inside the functions that need it; it dominates cold-start time and `--help` should be instant.

No other runtime dependencies without a strong reason.

### 11.2 Repository layout

```
parity/
├── pyproject.toml
├── README.md
├── PARITY_SPEC.md              # this file
├── src/parity/
│   ├── __init__.py
│   ├── cli.py                  # argument parsing, exit codes — thin
│   ├── model.py                # CanonicalAtom, CanonicalResidue, keys
│   ├── resolve.py              # file -> canonical structure  (core)
│   ├── dialects.py             # table loading + detection scoring
│   ├── stereo.py               # symmetry sets + prochiral geometry
│   ├── align.py                # chain pairing + residue alignment
│   ├── check.py                # single-file logic
│   ├── diff.py                 # two-file logic, difference classification
│   ├── render/
│   │   ├── human.py
│   │   └── json_out.py
│   └── data/
│       ├── symmetry.toml
│       └── dialects/
│           ├── pdbv3.toml
│           ├── pdbv2.toml
│           ├── amber.toml
│           └── charmm.toml
├── tools/
│   └── build_tables.py         # dev-only CCD table generator
└── tests/
    ├── fixtures/
    └── test_*.py
```

### 11.3 Dialect detection algorithm

1. Load all dialect tables and their markers.
2. For each candidate dialect, sum the weights of markers observed in the structure.
3. Normalize by the number of opportunities (a file with no histidines cannot score histidine markers; do not penalize it).
4. Confidence = margin between the top two normalized scores:
   - large margin → `confident`
   - small margin → `ambiguous`, and **report both candidates**
   - no markers observed at all → `insufficient evidence`, **do not guess**

A hydrogen-free file with no histidines and no unusual termini genuinely cannot be attributed. Saying so is correct behavior and builds more trust than a confident wrong answer.

5. Repeat per chain and per contiguous segment for §7.3 mixed-dialect detection.

### 11.4 Performance

| Target | Value |
|---|---|
| `parity check` on ~100k atoms | < 1 s wall clock |
| `parity diff` on two ~100k-atom files | < 2 s wall clock |
| `parity --help` | < 200 ms (lazy imports) |

Design rules that achieve this without effort:
- Single parse pass per file.
- Canonical keys are hashable; all matching is dict lookup. **No O(n²) atom search anywhere.**
- Geometry (§9.2, §9.3) computed per residue on small fixed-size arrays, not globally.
- Sequence alignment runs on residues, not atoms.

### 11.5 Output contract

**Human output:** terminal report as in §7.2 and §8.1. Fits on one screen for a typical case. Never dumps a per-atom list unless a verbosity flag is added later. Color is decoration only — the report must be fully readable with `--no-color`.

**JSON output:** stable, versioned, documented. Sketch:

```json
{
  "parity_version": "0.1.0",
  "schema_version": 1,
  "command": "diff",
  "files": ["a.pdb", "b.pdb"],
  "equivalent": true,
  "summary": {
    "chemistry": 0,
    "topology": 0,
    "geometry": {"heavy_atom_rmsd": 0.0},
    "naming": {"atoms": 412, "residues": 23}
  },
  "differences": [
    {
      "level": "naming",
      "kind": "residue_name",
      "chain": "A",
      "seq_id": 63,
      "from": "HSD",
      "to": "HIS",
      "count": 14,
      "message": "HSD -> HIS"
    }
  ],
  "issues": [],
  "exit_code": 0
}
```

`schema_version` is mandatory from v0. Downstream scripts will depend on this and breaking them silently is unacceptable.

---

## 12. Testing

Testing is not optional here. The tool's only claim is correctness of equivalence; that claim must be mechanically verified.

### 12.1 Fixture generation strategy (the important one)

Do not hand-write test PDBs for the main correctness tests. Instead:

1. Take a set of real structures spanning: all 20 amino acids, both nucleic acid types, disulfides, metals, ligands, glycans, gaps, altlocs, insertion codes.
2. Prepare each through **two different pipelines** — for example `tleap` (AMBER-flavored output) and `psfgen`/CHARMM-GUI (CHARMM-flavored output).
3. **Assertion: `parity diff` must report zero chemistry and zero topology differences between the two, and a nonzero naming count.**

This is the gold test. It directly encodes the product claim, and it will find real bugs in §9.2 and §9.3 that no synthetic test would.

### 12.2 Other required tests

- **Identity:** `diff FILE FILE` → exit 0, zero differences of every level. Trivially true, but catches resolver nondeterminism.
- **Ring-flip invariance:** synthetically swap `CD1`/`CD2` + `CE1`/`CE2` labels on a PHE. Must report `naming` only, never `geometry` or `chemistry`.
- **Prochiral inversion:** synthetically swap only `HB2`/`HB3` coordinates (not labels). Must be *detected*, not absorbed. This is the test that proves §9.3 was implemented and not faked.
- **Mutation detection:** mutate one residue. Must report exactly one `chemistry` difference.
- **Tautomer detection:** `HID` → `HIE`. Must be `chemistry`, not `naming`.
- **`MSE` handling:** must be `chemistry`, not `naming`.
- **Mixed dialect:** concatenate an AMBER chain and a CHARMM chain. `check` must flag it.
- **Ambiguity honesty:** a hydrogen-free, histidine-free file must return `insufficient evidence`, not a confident guess.
- **Format parity:** the same structure as `.pdb` and `.cif` must produce identical canonical keys and an empty diff.
- **Exit codes and JSON schema:** asserted explicitly.
- **Determinism:** running `check` twice on the same file produces byte-identical JSON.

### 12.3 CI

Run tests on Linux and macOS, Python 3.10–3.13. Include a runtime assertion on a large structure so performance regressions are caught.

---

## 13. Milestones

Each milestone has a Definition of Done. Do not proceed until it passes.

### M0 — Skeleton
Package scaffolding, `pyproject.toml`, CLI with both subcommands parsing arguments and returning exit code 2 with "not implemented".
**DoD:** `pip install -e .` works; `parity --help` runs in < 200 ms.

### M1 — Resolver and tables *(the hard one)*
`model.py`, `resolve.py`, `stereo.py`, `dialects.py`. TOML tables for `pdbv3`, `amber`, `charmm`, seeded via `tools/build_tables.py` from the CCD. Symmetry canonicalization (§9.2) and geometry-based prochiral assignment (§9.3) implemented and unit-tested.
**DoD:** given a structure, produce a deterministic canonical key for every atom; the ring-flip and prochiral tests in §12.2 pass.

### M2 — `check`
Dialect detection with confidence, inventory, protonation census, gaps, missing atoms, altlocs, unknowns, mixed-dialect detection. Human and JSON renderers.
**DoD:** correct output on all fixtures; ambiguity-honesty test passes; batch JSON Lines mode works with `jq`.

### M3 — `diff`
Chain pairing, residue alignment, atom matching, difference classification into the four levels, equivalence rule, exit codes.
**DoD:** the §12.1 gold test passes on the full fixture set — zero false chemistry/topology differences across independently prepped versions of the same structure.

### M4 — Release polish
README with the two example outputs from §7.2 and §8.1 verbatim, JSON schema documentation, `pdbv2` dialect, CI matrix, PyPI packaging.
**DoD:** a stranger can `pip install parity`, run it on their own file, and understand the output without reading documentation.

Realistic effort: M1 is the bulk. M2 and M3 are each substantially smaller once M1 is right. Total v0 is a small number of focused weekends, provided §5 is respected.

**Build order note:** implement `check` (M2) before `diff` (M3), even though `diff` was the original idea. `check` forces the dialect tables into a correct state, is easier to validate by eye, and is the better demo.

---

## 14. Open questions — verify, do not guess

**Q1. Prochiral hydrogen naming ↔ pro-R/pro-S mapping.**
Which of `HB2`/`HB3` (PDB v3) corresponds to which of CHARMM's `HB1`/`HB2`, and how each maps to pro-R/pro-S, must be verified against an authoritative source (IUPAC-IUB nomenclature recommendations, BMRB atom nomenclature tables, and the CCD's own atom/alt-atom identifiers) before `stereo.py` is written. **This is stated as a known unverified assumption in this spec — do not implement it from memory.** Encode the verified answer in the TOML tables with the citation in the `reference` field.

**Q2. Phosphate naming across force-field versions.**
`O1P`/`O2P` vs `OP1`/`OP2` usage varies by force field *version*, not just by force field. Determine which versions of AMBER and CHARMM nucleic acid parameter sets use which, and decide whether dialects need version granularity (e.g. `charmm27` vs `charmm36`) or whether markers can absorb the variation.

**Q3. CCD distribution.**
The full CCD is large. Decide whether to ship a pruned subset (standard residues, common ions, common solvents) with the package and treat everything else as "unknown", or ship the full component set. Leaning: pruned subset, since unknown-is-fine is already a first-class output (§4.2).

**Q4. GROMACS as a dialect.**
GROMACS naming depends on which force-field port is used, so it may not be a single coherent dialect. Investigate before adding; it may need to be `gromacs-amber` / `gromacs-charmm`.

**Q5. Insertion codes and non-contiguous numbering in alignment.**
Antibody-style numbering (insertion codes, gaps by convention) may break naive alignment. Decide handling before M3.

**Q6. Name availability.**
`parity` may be taken on PyPI. Alternatives: `pdbparity`, `same`, `pdbdiff`. Check before M0 — renaming after release is painful.

---

## 15. Post-v0 roadmap (do not build now)

Recorded here so the v0 architecture does not preclude them, and so they stay out of v0.

- **`parity translate --from X --to Y`** — the original motivating idea. Reuses the identical tables in reverse; `--verify` is just calling `diff` on the round trip. Deferred because a translator must be *complete* to be safe, while a diff only needs to be *correct*.
- **`parity renumber`** — transfer numbering between files by alignment (author vs. PDB vs. post-modeling vs. UniProt canonical).
- **`parity selection`** — translate selection masks across dialects and numbering (AMBER mask ↔ VMD ↔ MDAnalysis ↔ CHARMM).
- **`parity transplant`** — move a subset from one file into another by canonical key.
- **Patch format** — emit a diff as an applyable patch to replay prep decisions on an updated structure.
- **Topology cross-check** — diff a PDB against a `.prmtop` / `.psf`.
- **Git integration** — register as a `textconv` / diff driver so `git diff` on structure files shows semantic output. Cheap, high impact.
- **Three-way diff** — deposited / mine / colleague's.
- **Glycans, lipids, membranes** — GLYCAM and CHARMM carbohydrate dialects.

---

## 16. Glossary

- **altloc** — alternate location indicator; multiple modeled conformations of the same atom.
- **canonical key** — the dialect-independent atom identity defined in §9.1.
- **CCD** — wwPDB Chemical Component Dictionary; authoritative definitions of every chemical component in the PDB.
- **dialect** — a tool- or force-field-specific set of residue and atom naming conventions.
- **icode / insertion code** — a letter appended to a residue number, allowing residues to be inserted without renumbering.
- **prochiral** — a center whose two apparently identical substituents are actually distinguishable (pro-R / pro-S) by their spatial relationship to the rest of the molecule. See §9.3.
- **symmetry-equivalent atoms** — atoms genuinely interchangeable by a symmetry of the residue, whose labels may be swapped with no chemical consequence. See §9.2.
- **tautomer** — for histidine, which ring nitrogen carries the proton (delta vs. epsilon). A real chemical difference, not a naming difference.
