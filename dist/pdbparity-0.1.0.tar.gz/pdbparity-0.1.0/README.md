# parity — audit and compare PDB/mmCIF structure files

`parity` is a fast, read-only command-line tool that answers two questions about PDB/mmCIF structure files: **"what is this file?"** and **"are these two files the same molecule?"**

---

## The problem

A single structure passes through many tools — RCSB, a modeling/repair step, a force-field-specific system builder (tleap, psfgen, CHARMM-GUI, pdb2gmx), simulation, analysis. Each stage silently rewrites atom and residue names according to its own conventions. The result is three failure modes: `diff` reports thousands of spurious differences between chemically identical files; a prep step mutates the molecule (drops a cofactor, changes a histidine tautomer, substitutes selenomethionine) and nothing announces it until weeks later; or a file assembled from pieces written by different tools loads and minimizes fine, then produces garbage. There is no tool that reports "chemically identical, 412 atoms renamed" or "chain A is CHARMM, chain B is AMBER." That gap is what `parity` fills.

---

## Install

```
pip install pdbparity
```

Requires Python 3.10+.

---

## Quick start

### `parity check` — audit a single file

```
$ parity check prepped.pdb

  dialect     CHARMM  (confident)
                HSD/HSE/HSP · HB1/HB2 · OT1/OT2 termini · TIP3 water

  contents    2 chains · 487 residues · 7,812 atoms
              1 ligand (LIG) · 2 Zn · 41 waters

  protonation HIS: 9 HSD, 4 HSE, 1 HSP
              CYS: 6 in 3 disulfides, 4 free
              ASP/GLU: all standard

  ! gap        chain A 87-93 missing (numbering + CA-CA distance agree)
  ! altloc     3 residues carry alternate locations
  ! unknown    LIG:C17 matches no known dialect

  x 3 issues
```

**Reading the output:**

- `dialect` — detected naming convention and the evidence (residue/atom names) that drove the decision. Confidence is `confident`, `ambiguous`, or `insufficient evidence`.
- `contents` — inventory: chains, residues, atoms, plus ligands, ions, and waters separately.
- `protonation` — histidine tautomer counts, cysteine disulfide vs. free, non-standard protonation states for ASP/GLU/LYS.
- `! gap` — chain breaks detected by both residue numbering and CA–CA distance.
- `! altloc` — residues carrying alternate locations that may need to be resolved before simulation.
- `! unknown` — atoms or residues that match no known dialect table. Reported as a first-class finding, not an error.
- `x N issues` — summary count; drives the exit code.

Mixed-dialect detection is the flagship capability. If chains or segments within a file use different naming conventions (a common artifact of concatenation or partial conversion), `check` will flag it:

```
  ! dialect    file is not internally consistent
                 chain A          CHARMM  (HSD, HB1/HB2)
                 chain B          AMBER   (HID, HB2/HB3)
```

### `parity diff` — compare two files

**Equivalent files** (same molecule, different force-field naming):

```
$ parity diff 1abc_charmm.pdb 1abc_amber.pdb

  chemistry   identical
  topology    identical
  geometry    0.000 A heavy-atom RMSD
  naming      412 atoms across 23 residues

    HSD -> HIS            14 residues
    HSE -> HIS             9 residues
    HB1/HB2 -> HB2/HB3   198 atoms  (prochiral, order preserved)
    O1P/O2P -> OP1/OP2    26 atoms

  = chemically equivalent
```

**Non-equivalent files** (real differences found):

```
$ parity diff deposited.pdb prepped.pdb

  chemistry   2 differences
  topology    3 differences
  geometry    0.31 A heavy-atom RMSD

  ! MSE 214 -> MET 214          selenomethionine substituted
  ! GOL 401 removed             crystallization additive
  + residues 87-93              built (absent in deposited)
  ~ HIS 63                      HID -> HIE (tautomer changed)

  x structures are not equivalent
```

**Reading the output:**

- `chemistry` / `topology` / `geometry` / `naming` — counts at each level (see [What "equivalent" means](#what-equivalent-means)).
- `!` — a chemistry difference (molecular identity changed).
- `+` — a topology difference (residues or atoms added).
- `-` — a topology difference (residues or atoms removed).
- `~` — a chemistry difference (same residue, different protonation or tautomer).
- `= chemically equivalent` / `x structures are not equivalent` — the final verdict, which also drives the exit code.

Differences that vanish after canonicalization (HSD→HIS, HB1→HB3, O1P→OP1) are classified as `naming`. Only `chemistry` and `topology` differences break equivalence.

---

## Commands

### `parity check FILE`

Identify dialect, inventory contents, and flag inconsistencies in a single structure file. Accepts PDB and mmCIF.

Shared options:

| Flag | Default | Meaning |
|---|---|---|
| `--json` | off | Emit machine-readable JSON to stdout |
| `--hydrogens` | off | Include hydrogens in reporting |
| `--dialect NAME` | auto | Override dialect auto-detection |
| `--model N` | 1 | Which model to use in a multi-model file |
| `--quiet` | off | Suppress report; use exit code only |
| `--no-color` | auto | Disable ANSI color (auto-disabled when not a TTY) |
| `--version` | | Print version and exit |
| `--help` | | Print help and exit |

Batch use — `check` accepts multiple files and emits one JSON object per file (JSON Lines):

```bash
parity check structures/*.pdb --json | jq -r 'select(.issue_count > 0) | .file'
```

### `parity diff FILE_A FILE_B`

Compare two structure files. Reports differences classified by level, and exits 0 if the structures are chemically equivalent.

Shared options: same as `check` above.

`diff`-only options:

| Flag | Default | Meaning |
|---|---|---|
| `--level LEVEL` | `all` | One of `naming`, `topology`, `chemistry`, `geometry`, `all` |
| `--rmsd-threshold Å` | `0.0` | Geometric differences below this are not reported |
| `--ignore-water` | off | Exclude solvent from comparison |
| `--ignore-hetatm` | off | Exclude non-polymer entities |

---

## What "equivalent" means

Two structures are **chemically equivalent** if there are zero `chemistry` differences and zero `topology` differences. Naming and geometry differences do not break equivalence.

**naming** — Same molecule, different labels. Disappears under canonicalization. Examples: `HSD`→`HIS`, `HB1/HB2`→`HB2/HB3`, `O1P`→`OP1`, `TIP3`→`HOH`. Ring-flip label swaps on PHE/TYR are also naming differences, handled geometrically to avoid false positives from coordinate-based label choices.

**topology** — The composition of the model changed. Residues or chains added or removed, gaps opened or closed, waters or ions stripped, alternate locations resolved. These are real changes to what is in the file, but not necessarily to the chemistry of what remains.

**chemistry** — Molecular identity changed. Mutations, selenomethionine substitution (`MSE`→`MET`), protonation state changes (`ASH`/`GLH`/`LYN`), histidine tautomer changes (`HID`→`HIE`), disulfides formed or broken, a ligand replaced. These are the differences that affect simulation behavior.

**geometry** — Same atoms, moved. Reported as global and per-residue heavy-atom RMSD. Does not affect equivalence.

---

## Exit codes

Composable with shell pipelines, `make`, Snakemake, and Nextflow — the same convention as `diff(1)`.

| Code | Meaning |
|---|---|
| `0` | `check`: no issues found. `diff`: structures are equivalent. |
| `1` | `check`: one or more issues found. `diff`: differences found. |
| `2` | Error — file unreadable, unparseable, or bad arguments. |

---

## Supported dialects

| Dialect | Description |
|---|---|
| `pdbv3` | PDB format v3.0 standard — the canonical reference; all other dialects map through it. |
| `charmm` | CHARMM36 / psfgen / CHARMM-GUI — `HSD`/`HSE`/`HSP`, `HB1`/`HB2`, `OT1`/`OT2` termini, `TIP3` water. |
| `amber` | AMBER / tleap — `HID`/`HIE`/`HIP`, `HB2`/`HB3`, `OP1`/`OP2`, `WAT` water. |
| `pdbv2` | Legacy PDB naming — still common in older deposited files and some analysis tools. |

Dialect tables are plain TOML files in `src/parity/data/dialects/`. Adding support for a new force field is a pull request against a data file, with no Python changes required.

---

## JSON output

Pass `--json` to any command to receive a machine-readable report on stdout. The `schema_version` field is stable across patch releases; downstream scripts should assert on it.

```json
{
  "parity_version": "0.1.0",
  "schema_version": 1,
  "command": "diff",
  "files": ["a.pdb", "b.pdb"],
  "equivalent": true,
  "summary": {
    "chemistry": 0,
    "topology": 0,
    "geometry": {"heavy_atom_rmsd": 0.0},
    "naming": {"atoms": 412, "residues": 23}
  },
  "differences": [...],
  "issues": [],
  "exit_code": 0
}
```

`schema_version` increments on any breaking change to the JSON structure. The human-readable report format is not considered stable until v1.0.

---

## License

MIT
